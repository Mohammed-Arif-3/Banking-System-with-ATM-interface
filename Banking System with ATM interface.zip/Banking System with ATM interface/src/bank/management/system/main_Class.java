package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class main_Class extends JFrame implements ActionListener {

    JButton b1,b2,b3,b4,b5,b6,b7;
    String pin;
        main_Class(String pin){
            this.pin=pin;
            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/atm.jpg"));
            Image i2 = i1.getImage().getScaledInstance(1150, 800, Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            JLabel image = new JLabel(i3);
            image.setBounds(0, 0, 1550, 830);
            add(image);


            JLabel label=new JLabel("Please Select Your Transaction");
            label.setForeground(Color.WHITE);
            label.setBounds(500, 300, 380, 35);
            label.setFont(new Font("System", Font.BOLD, 16));
            image.add(label);

            b1 = new JButton("DEPOSIT");
            b1.setBounds(400, 415, 130, 28);
            b1.setBackground(new Color(146, 189, 190));
            b1.setForeground(Color.WHITE);
            b1.addActionListener(this);
            b1.setFont(new Font("Raleway",Font.BOLD,9));
            image.add(b1);

            b2 = new JButton("CASH WITHDRAWL");
            b2.setBounds(730, 415, 130, 28);
            b2.setBackground(new Color(146, 189, 190));
            b2.setForeground(Color.WHITE);
            b2.addActionListener(this);
            b2.setFont(new Font("Raleway",Font.BOLD,9));
            image.add(b2);


            b3 = new JButton("FAST CASH");
            b3.setBounds(400, 450, 130, 28);
            b3.setBackground(new Color(146, 189, 190));
            b3.setForeground(Color.WHITE);
            b3.addActionListener(this);
            b3.setFont(new Font("Raleway",Font.BOLD,9));
            image.add(b3);

            b4 = new JButton("MINI STATEMENT");
            b4.setBounds(730, 450, 130, 28);
            b4.setBackground(new Color(146, 189, 190));
            b4.setForeground(Color.WHITE);
            b4.setFont(new Font("Raleway",Font.BOLD,9));
            b4.addActionListener(this);
            image.add(b4);


            b5 = new JButton("PIN CHANGE");
            b5.setBounds(400, 485, 130, 28);
            b5.setBackground(new Color(146, 189, 190));
            b5.setForeground(Color.WHITE);
            b5.setFont(new Font("Raleway",Font.BOLD,9));
            b5.addActionListener(this);
            image.add(b5);

            b6 = new JButton("BALANCE ENQUIRY");
            b6.setBounds(730, 485, 130, 28);
            b6.setBackground(new Color(146, 189, 190));
            b6.setForeground(Color.WHITE);
            b6.setFont(new Font("Raleway",Font.BOLD,9));
            b6.addActionListener(this);
            image.add(b6);

            b7 = new JButton("EXIT");
            b7.setBounds(730, 518, 130, 28);
            b7.setBackground(new Color(146, 189, 190));
            b7.setForeground(Color.WHITE);
            b7.setFont(new Font("Raleway",Font.BOLD,9));
            b7.addActionListener(this);
            image.add(b7);



            setLayout(null);
            setSize(1550,1080);
            setLocation(0,0);
            setVisible(true);
            getContentPane().setBackground(new Color(133, 133, 84));
        }


    public static void main(String[] args) {
        new main_Class("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if(e.getSource()==b1){
               new Deposit(pin);
                setVisible(false);
            } else if (e.getSource()==b7) {
                System.exit(0);
            } else if (e.getSource()==b2) {
                new Withdrawl(pin);
                setVisible(false);
            } else if (e.getSource()==b6) {
                new BalanceEnquiry(pin);
                setVisible(false);

            } else if (e.getSource()==b3) {
                new FastCash(pin);
                setVisible(false);
                
            } else if (e.getSource()==b5) {
                new Pin(pin);
                setVisible(false);
            } else if (e.getSource()==b4) {
                new Mini(pin);
            }
        }
        catch (Exception E){

        }
//        setVisible(false);
//        new main_Class(pin);
    }
}
