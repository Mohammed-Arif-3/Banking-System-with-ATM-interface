package bank.management.system;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Signup extends JFrame implements ActionListener{
    JTextField textName,textFather,textEmail,textAddress,textPin,textState,textDistrict;
    JDateChooser dateChooser;
    JRadioButton r1,r2;
    JButton next;
    Random ran=new Random();
    long first4=(ran.nextLong() % 9000L)+1000L;


    String first=" "+Math.abs(first4);
    Signup(){

        super("APPLICATION FORM");
        if(first4<0){
            first4=-1*first4;
        }
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2=i1.getImage().getScaledInstance(200,150,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image =new JLabel(i3);
        image.setBounds(25,10,100,100);
        add(image);

        JLabel label1=new JLabel("APPLICATION FORM NO. "+first4);
        label1.setBounds(230,20,600,40);
        label1.setFont(new Font("Raleway",Font.BOLD,28));
        add(label1);

        JLabel label2=new JLabel("Page 1");
        label2.setFont(new Font("Raleway",Font.BOLD,18));
        label2.setBounds(380,70,600,30);
        add(label2);

        JLabel label3=new JLabel("Personal Details");
        label3.setFont(new Font("Raleway",Font.BOLD,18));
        label3.setBounds(340,90,600,30);
        add(label3);

        JLabel label4=new JLabel("Full Name :");
        label4.setFont(new Font("Raleway",Font.BOLD,18));
        label4.setBounds(90,150,600,30);
        add(label4);

         textName=new JTextField();
        textName.setFont(new Font("Raleway",Font.BOLD,15));
        textName.setBounds(260,155,400,25);
        add(textName);

        JLabel label5=new JLabel("Father's Name :");
        label5.setFont(new Font("Raleway",Font.BOLD,18));
        label5.setBounds(90,210,600,30);
        add(label5);

         textFather=new JTextField();
        textFather.setFont(new Font("Raleway",Font.BOLD,15));
        textFather.setBounds(260,215,400,25);
        add(textFather);

        JLabel label6=new JLabel("Date Of Birth :");
        label6.setFont(new Font("Raleway",Font.BOLD,18));
        label6.setBounds(90,270,600,30);
        add(label6);

        dateChooser =new JDateChooser();
        dateChooser.setForeground(new Color(105,105,105));
        dateChooser.setBounds(260,270,400,30);
        add(dateChooser);

        JLabel label7=new JLabel("Gender :");
        label7.setFont(new Font("Raleway",Font.BOLD,18));
        label7.setBounds(90,330,600,30);
        add(label7);

        r1=new JRadioButton("Male");
        r1.setFont(new Font("Raleway",Font.BOLD,15));
        r1.setBackground(new Color(106,136,116));
        r1.setBounds(260,330,60,30);
        add(r1);

        r2=new JRadioButton("Female");
        r2.setFont(new Font("Raleway",Font.BOLD,15));
        r2.setBackground(new Color(106,136,116));
        r2.setBounds(350,330,90,30);
        add(r2);

        ButtonGroup button=new ButtonGroup();
        button.add(r1);
        button.add(r2);


        JLabel label13=new JLabel("Email :");
        label13.setFont(new Font("Raleway",Font.BOLD,18));
        label13.setBounds(90,390,600,30);
        add(label13);


        textEmail=new JTextField();
        textEmail.setFont(new Font("Raleway",Font.BOLD,15));
        textEmail.setBounds(260,390,400,30);
        add(textEmail);

        JLabel label8=new JLabel("Address :");
        label8.setFont(new Font("Raleway",Font.BOLD,18));
        label8.setBounds(90,450,600,30);
        add(label8);
//
//
         textAddress=new JTextField();
        textAddress.setFont(new Font("Raleway",Font.BOLD,15));
        textAddress.setBounds(260,450,400,45);
        add(textAddress);
//
        JLabel label9=new JLabel("District :");
        label9.setFont(new Font("Raleway",Font.BOLD,18));
        label9.setBounds(90,510,600,30);
        add(label9);


         textDistrict=new JTextField();
        textDistrict.setFont(new Font("Raleway",Font.BOLD,15));
        textDistrict.setBounds(260,510,400,30);
        add(textDistrict);
//
        JLabel label10=new JLabel("Pin Code :");
        label10.setFont(new Font("Raleway",Font.BOLD,18));
        label10.setBounds(90,570,600,30);
        add(label10);


         textPin=new JTextField();
        textPin.setFont(new Font("Raleway",Font.BOLD,15));
        textPin.setBounds(260,570,400,30);
        add(textPin);

        JLabel label11=new JLabel("State :");
        label11.setFont(new Font("Raleway",Font.BOLD,18));
        label11.setBounds(90,630,600,30);
        add(label11);


         textState=new JTextField();
        textState.setFont(new Font("Raleway",Font.BOLD,15));
        textState.setBounds(260,630,400,30);
        add(textState);


        next=new JButton("Next");
        next.setFont(new Font("Arial",Font.BOLD,14));
        next.setForeground(Color.WHITE);
        next.setBackground(Color.BLACK);
        next.setBounds(330,670,150,40);

          next.addActionListener(this);
        add(next);


        getContentPane().setBackground(new Color(106,136,116));
        setLayout(null);
        setSize(850,750);
        setLocation(360,40);
        setVisible(true);


    }





    public static void main(String[] args) {
        new Signup();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String formno= String.valueOf(first4);
        String name=  textName.getText();
        String fname=  textFather.getText();
        String dob=((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
        String gender=null;
        if(r1.isSelected()){
            gender="Male";
        }
        else if(r2.isSelected()) {
            gender="Female";
        }

        String email=textEmail.getText();
        String address=  textAddress.getText();
        String  district=  textDistrict.getText();
        String pin=  textPin.getText();
        String state=  textState.getText();

        try{
            if (textName.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Fill all the fields");
            }
            else {
                Con con1=new Con();
                String q="insert into singup values('"+formno+"','"+name+"',' "+fname+ "',' "+dob+ "',' "+gender+ "',' "+email+ "',' "+address+ "',' "+ district+ "',' "+pin+ "','"+state+"')";
                con1.statement.executeUpdate(q);
                new Signup2(formno);
                setVisible(false);
            }
        }
        catch (Exception E){
            E.printStackTrace();
        }
    }
}
