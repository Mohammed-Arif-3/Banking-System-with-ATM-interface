package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Signup2 extends JFrame implements ActionListener {
    String formno;
    JTextField pan,aadhar;
    JRadioButton r1,r2,e1,e2;
    JButton next;
    JComboBox comboBox,comboBox1,comboBox2,comboBox3,comboBox4;
    Signup2(String formno){

        super("APPLICATION FORM");
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2=i1.getImage().getScaledInstance(200,150,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image =new JLabel(i3);
        image.setBounds(25,10,100,100);
        add(image);

        this.formno=formno;

        JLabel label2=new JLabel("Page 2");
        label2.setFont(new Font("Raleway",Font.BOLD,23));
        label2.setBounds(380,60,600,30);
        add(label2);

        JLabel label3=new JLabel("Additional Details");
        label3.setFont(new Font("Raleway",Font.BOLD,23));
        label3.setBounds(340,100,600,30);
        add(label3);

        JLabel label4=new JLabel("Religion :");
        label4.setFont(new Font("Raleway",Font.BOLD,18));
        label4.setBounds(130,150,600,30);
        add(label4);

        String religion[]={"Muslim","Hindu","Christian","Sikh"};
        comboBox=new JComboBox(religion);
        comboBox.setBounds(350,150,320,30);
        comboBox.setBackground(new Color(134, 132, 132));
        comboBox.setFont(new Font("Raleway",Font.BOLD,14));
        add(comboBox);
        JLabel label5=new JLabel("Category :");
        label5.setFont(new Font("Raleway",Font.BOLD,18));
        label5.setBounds(130,200,600,30);
        add(label5);

        String category[]={"General","OBC","SC","ST","Others"};
        comboBox1=new JComboBox(category);
        comboBox1.setBounds(350,200,320,30);
        comboBox1.setBackground(new Color(134, 132, 132));
        comboBox1.setFont(new Font("Raleway",Font.BOLD,14));
        add(comboBox1);
        JLabel label6=new JLabel("Income :");
        label6.setFont(new Font("Raleway",Font.BOLD,18));
        label6.setBounds(130,250,600,30);
        add(label6);

        String income[]={"Null","<1,50,000","<2,50,000","<5,00,000", "Upto 10,00,000","Above 10,00,000"};
        comboBox2=new JComboBox(income);
        comboBox2.setBounds(350,250,320,30);
        comboBox2.setBackground(new Color(134, 132, 132));
        comboBox2.setFont(new Font("Raleway",Font.BOLD,14));
        add(comboBox2);
        JLabel label7=new JLabel("Education :");
        label7.setFont(new Font("Raleway",Font.BOLD,18));
        label7.setBounds(130,300,600,30);
        add(label7);

        String education[]={"Under-Graduate","Graduate","Post-Graduate","Doctrate","Others"};
        comboBox3=new JComboBox(education);
        comboBox3.setBounds(350,300,320,30);
        comboBox3.setBackground(new Color(134, 132, 132));
        comboBox3.setFont(new Font("Raleway",Font.BOLD,14));
        add(comboBox3);
        JLabel label8=new JLabel("Occupation :");
        label8.setFont(new Font("Raleway",Font.BOLD,18));
        label8.setBounds(130,350,600,30);
        add(label8);

        String occupation[]={"Salaried","Self-Employed","Business","Student","Retired","Other"};
        comboBox4=new JComboBox(occupation);
        comboBox4.setBounds(350,350,320,30);
        comboBox4.setBackground(new Color(134, 132, 132));
        comboBox4.setFont(new Font("Raleway",Font.BOLD,14));
        add(comboBox4);

        JLabel label9=new JLabel("PAN Number :");
        label9.setFont(new Font("Raleway",Font.BOLD,18));
        label9.setBounds(130,400,600,30);
        add(label9);

        pan=new JTextField();
        pan.setFont(new Font("Raleway",Font.BOLD,15));
        pan.setBounds(350,400,320,30);
        add(pan);



        JLabel label10=new JLabel("Aadhar Number :");
        label10.setFont(new Font("Raleway",Font.BOLD,18));
        label10.setBounds(130,450,600,30);
        add(label10);

        aadhar=new JTextField();
        aadhar.setFont(new Font("Raleway",Font.BOLD,15));
        aadhar.setBounds(350,450,320,30);
        add(aadhar);

        JLabel label11=new JLabel("Senior Citizen :");
        label11.setFont(new Font("Raleway",Font.BOLD,18));
        label11.setBounds(130,500,600,30);
        add(label11);

        r1=new JRadioButton("Yes");
        r1.setFont(new Font("Raleway",Font.BOLD,15));
        r1.setBackground(new Color(133, 133, 84));
        r1.setBounds(350,500,60,30);
        add(r1);

        r2=new JRadioButton("No");
        r2.setFont(new Font("Raleway",Font.BOLD,15));
        r2.setBackground(new Color(133, 133, 84));
        r2.setBounds(450,500,90,30);
        add(r2);

        ButtonGroup button=new ButtonGroup();
        button.add(r1);
        button.add(r2);

        JLabel label12=new JLabel("Existing Account :");
        label12.setFont(new Font("Raleway",Font.BOLD,18));
        label12.setBounds(130,550,600,30);
        add(label12);

        e1=new JRadioButton("Yes");
        e1.setFont(new Font("Raleway",Font.BOLD,15));
        e1.setBackground(new Color(133, 133, 84));
        e1.setBounds(350,550,90,30);
        add(e1);

        e2=new JRadioButton("No");
        e2.setFont(new Font("Raleway",Font.BOLD,15));
        e2.setBackground(new Color(133, 133, 84));
        e2.setBounds(450,550,90,30);
        add(e2);

        ButtonGroup button1=new ButtonGroup();
        button1.add(e1);
        button1.add(e2);

        JLabel label13=new JLabel("Form No:");
        label13.setFont(new Font("Raleway",Font.BOLD,23));
        label13.setBounds(600,30,600,30);
        add(label13);

        JLabel label14=new JLabel(formno);
        label14.setFont(new Font("Raleway",Font.BOLD,23));
        label14.setBounds(710,30,600,30);
        add(label14);

        next=new JButton("Next");
        next.setFont(new Font("Arial",Font.BOLD,14));
        next.setForeground(Color.WHITE);
        next.setBackground(Color.BLACK);
        next.setBounds(330,670,150,40);
        next.addActionListener(this);
        add(next);

        setLayout(null);
        setSize(850,750);
        setLocation(360,40);
        setVisible(true);
        getContentPane().setBackground(new Color(133, 133, 84));
    }

    public static void main(String[] args) {
        new Signup2("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String rel=(String) comboBox.getSelectedItem();
        String cato=(String) comboBox1.getSelectedItem();
        String inc=(String) comboBox2.getSelectedItem();
        String edu=(String) comboBox3.getSelectedItem();
        String occ=(String) comboBox4.getSelectedItem();

        String Pan= pan.getText();
        String Aadhar=aadhar.getText();
        String scitizen="";
        if(r1.isSelected()){
            scitizen="yes";
        }
        else if(r2.isSelected()){
            scitizen="No";
        }

        String eAccount="";
        if(r1.isSelected()){
            eAccount="yes";
        }
        else if(r2.isSelected()){
            eAccount="No";
        }
        try{
            if(pan.getText().equals("")||aadhar.getText().equals("")){
                JOptionPane.showMessageDialog(null,"fill all the fields");
            }
            else {
                Con c1=new Con();
                String q="insert into singuptwo values('"+formno+"','"+rel+"','"+cato+"','"+inc+"','"+edu+"','"+occ+"','"+Pan+"','"+Aadhar+"','"+scitizen+"','"+eAccount+"')";
                c1.statement.executeUpdate(q);
                new Signup3(formno);
                setVisible(false);
            }
        }
        catch(Exception E){
            E.printStackTrace();
        }
    }
}
