package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Signup3 extends JFrame implements ActionListener {
    JRadioButton r1,r2,r3,r4;
    JCheckBox c1,c2,c3,c4,c5,c6,c7;
    String formno;
    JButton s,c;
    Signup3(String formno){
        super("FORM DETAILS");
        this.formno=formno;

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2=i1.getImage().getScaledInstance(200,150,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image =new JLabel(i3);
        image.setBounds(25,10,100,100);
        add(image);

        JLabel label2=new JLabel("Page 3");
        label2.setFont(new Font("Raleway",Font.BOLD,23));
        label2.setBounds(380,60,600,30);
        add(label2);

        JLabel label3=new JLabel("Account Details");
        label3.setFont(new Font("Raleway",Font.BOLD,23));
        label3.setBounds(340,100,600,30);
        add(label3);

        JLabel label4=new JLabel("Account Type :");
        label4.setFont(new Font("Raleway",Font.BOLD,18));
        label4.setBounds(130,150,600,30);
        add(label4);
        r1=new JRadioButton("Saving Account");
        r1.setFont(new Font("Raleway",Font.BOLD,15));
        r1.setBackground(new Color(133, 133, 84));
        r1.setBounds(150,190,250,20);
        add(r1);

        r2=new JRadioButton("Fixed Deposit Account");
        r2.setFont(new Font("Raleway",Font.BOLD,15));
        r2.setBackground(new Color(133, 133, 84));
        r2.setBounds(430,190,250,20);
        add(r2);

        r3=new JRadioButton("Current Account");
        r3.setFont(new Font("Raleway",Font.BOLD,15));
        r3.setBackground(new Color(133, 133, 84));
        r3.setBounds(150,220,250,20);
        add(r3);

        r4=new JRadioButton("Recurring Deposit Account");
        r4.setFont(new Font("Raleway",Font.BOLD,15));
        r4.setBackground(new Color(133, 133, 84));
        r4.setBounds(430,220,250,20);
        add(r4);

        ButtonGroup button=new ButtonGroup();
        button.add(r1);
        button.add(r2);
        button.add(r3);
        button.add(r4);

        JLabel label5=new JLabel("Card Number :");
        label5.setFont(new Font("Raleway",Font.BOLD,18));
        label5.setBounds(130,260,600,30);
        add(label5);
        JLabel label6=new JLabel("(Your 16-digit Card Number)");
        label6.setFont(new Font("Raleway",Font.BOLD,12));
        label6.setBounds(130,290,600,30);
        add(label6);
        JLabel label7=new JLabel("XXXX-XXXX-XXXX-7993");
        label7.setFont(new Font("Raleway",Font.BOLD,14));
        label7.setBounds(430,260,600,30);
        add(label7);
        JLabel label8=new JLabel("(It would appear on atm card/cheque Book and Statements)");
        label8.setFont(new Font("Raleway",Font.BOLD,12));
        label8.setBounds(430,290,600,30);
        add(label8);


        JLabel label9=new JLabel("PIN :");
        label9.setFont(new Font("Raleway",Font.BOLD,16));
        label9.setBounds(130,330,600,30);
        add(label9);
        JLabel label10=new JLabel("XXXX");
        label10.setFont(new Font("Raleway",Font.BOLD,16));
        label10.setBounds(430,330,600,30);
        add(label10);
        JLabel label11=new JLabel("(4-digit Password)");
        label11.setFont(new Font("Raleway",Font.BOLD,12));
        label11.setBounds(130,350,600,30);
        add(label11);
        JLabel label12=new JLabel("Serivce Required");
        label12.setFont(new Font("Raleway",Font.BOLD,18));
        label12.setBounds(130,400,600,30);
        add(label12);

        c1=new JCheckBox("ATM Card");
        c1.setBackground(new Color(133, 133, 84));
        c1.setFont(new Font("Raleway",Font.BOLD,14));
        c1.setBounds(130,430,250,30);
        add(c1);
        c2=new JCheckBox("Internet Banking");
        c2.setBackground(new Color(133, 133, 84));
        c2.setFont(new Font("Raleway",Font.BOLD,14));
        c2.setBounds(450,430,350,30);
        add(c2);
        c3=new JCheckBox("Mobile Banking");
        c3.setBackground(new Color(133, 133, 84));
        c3.setFont(new Font("Raleway",Font.BOLD,14));
        c3.setBounds(130,465,250,30);
        add(c3);
        c4=new JCheckBox("E-Mail Alerts");
        c4.setBackground(new Color(133, 133, 84));
        c4.setFont(new Font("Raleway",Font.BOLD,14));
        c4.setBounds(450,465,350,30);
        add(c4);
        c5=new JCheckBox("Cheque Book");
        c5.setBackground(new Color(133, 133, 84));
        c5.setFont(new Font("Raleway",Font.BOLD,14));
        c5.setBounds(130,500,250,30);
        add(c5);
        c6=new JCheckBox("E-Statement");
        c6.setBackground(new Color(133, 133, 84));
        c6.setFont(new Font("Raleway",Font.BOLD,14));
        c6.setBounds(450,500,350,30);
        add(c6);
        c7=new JCheckBox("I here by declares that the above entered details correct to the best of my knowledge.");
        c7.setBackground(new Color(133, 133, 84));
        c7.setFont(new Font("Raleway",Font.BOLD,12));
        c7.setBounds(130,580,600,30);
        add(c7);

        JLabel label13=new JLabel("Form No :");
        label13.setFont(new Font("Raleway",Font.BOLD,18));
        label13.setBounds(600,30,600,30);
        add(label13);

        JLabel label14=new JLabel();
        label14.setFont(new Font("Raleway",Font.BOLD,18));
        label14.setBounds(680,30,600,30);
        add(label14);
        s=new JButton("Submit");
        s.setFont(new Font("Raleway",Font.BOLD,12));
        s.setBackground(Color.BLACK);
        s.setForeground(Color.WHITE);
        s.setBounds(250,620,100,30);
        s.addActionListener(this);
        add(s);
        c=new JButton("Cancel");
        c.setFont(new Font("Raleway",Font.BOLD,12));
        c.setBackground(Color.BLACK);
        c.setForeground(Color.WHITE);
        c.setBounds(400,620,100,30);
        c.addActionListener(this);
        add(c);




        setLayout(null);
        setSize(850,700);
        setLocation(360,40);
        setVisible(true);
        getContentPane().setBackground(new Color(133, 133, 84));
    }

    public static void main(String[] args) {
        new Signup3("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
            String atype=null;
            if(r1.isSelected()){
                atype="Saving Account";
            } else if (r2.isSelected()) {
                atype="Fixed Deposit Account";
            } else if (r3.isSelected()) {
                atype="Current Account";
            } else if (r4.isSelected()) {
                atype="Recurring Deposit Account";
            }
        Random ran=new Random();
            long first7=(ran.nextLong()%90000000L)+1409963000000000L;
            String cardno=" "+Math.abs(first7);
            long first3=(ran.nextLong()%9000L)+1000L;
            String pin=""+Math.abs(first3);

            String fac="";
            if (c1.isSelected()){
                fac =fac+"ATM CARD";
            } else if (c2.isSelected()) {
                fac=fac+"Internet Banking";
            } else if (c3.isSelected()) {
                fac=fac+"Mobile Banking";
            } else if (c4.isSelected()) {
                fac=fac+"E-Mail Alerts";
            } else if (c5.isSelected()) {
                fac=fac+"Cheque Book";
            } else if (c6.isSelected()) {
                fac=fac+"E-Statement";
            }
            try{
                if (e.getSource()==s){
                    if (atype.equals("")||!c7.isSelected()){
                        JOptionPane.showMessageDialog(null,"Fill all the fields");
                    }
                    else {
                        Con c1=new Con();
                        String q1="insert into signupthree values('"+formno+"','"+atype+"','"+cardno+"','"+pin+"','"+fac+"')";
                        String q2="insert into login values('"+formno+"','"+cardno+"','"+pin+"')";
                        c1.statement.executeUpdate(q1);

                        c1.statement.executeUpdate(q2);
                        JOptionPane.showMessageDialog(null,"Card Number :"+cardno+"\n pin :"+pin);
                        new Deposit(pin);
                        setVisible(false);
                    }
                } else if (e.getSource()==c) {
                    System.exit(0);
                }
            }
            catch (Exception E){
                E.printStackTrace();
            }
    }
}
