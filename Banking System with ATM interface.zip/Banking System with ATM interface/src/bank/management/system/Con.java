package bank.management.system;

import java.sql.*;



public class Con {
Statement statement;
    Connection connection;
    public Con(){


        try{
            connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/bankSystem","root","admin");
            statement=connection.createStatement();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

}
